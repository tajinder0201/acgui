public class Order {
    private String customerName;
    private int garments;
    public Order(String customerName, int garments) {
        setCustomerName(customerName);
        setGarments(garments);

    }
    public void setCustomerName(String cN){
        this.customerName=cN;
    }
    public void setGarments(int g){
        this.garments=g;
    }
    public String getCustomerName(){
        return customerName;
    }
    public int getGarments(){
        return garments;
    }
    public double calculateCharge(){
        int number = garments;
        double charge;
        if (number <= 2){
            charge = number*8.50;
        }else if(number==3){
            charge= 20;
        }else{
            number=   number - 3;
            charge= 20+ ( number *6.50) ;
        }      
        return charge;
    }
}