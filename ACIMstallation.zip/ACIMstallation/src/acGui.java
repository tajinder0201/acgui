    /*
    Programmer: Bruce McKenzie
    Course: Programming Fundamentals COIT 11222
    File: RockyDryCleanersGUI.java
    Purpose: Assignment Two -- Rocky Dry Cleaners windowed application
    Date: 5 March 2019
    */

    import java.awt.FlowLayout;
    import java.awt.Font;

    import java.awt.event.ActionListener;
    import java.awt.event.ActionEvent;
    import java.awt.event.WindowAdapter;
    import java.awt.event.WindowEvent;
import static java.awt.image.ImageObserver.HEIGHT;
    import java.lang.reflect.Array;


    import javax.swing.JFrame;
    import javax.swing.JLabel;
    import javax.swing.JButton;
    import javax.swing.JTextField;
    import javax.swing.JTextArea;
    import javax.swing.JOptionPane;
    import javax.swing.JScrollPane;

    // TODO -- create Order class (separate file)

/**
 *
 * @author DEll
 */
public class acGui extends JFrame 
    {

         public int currentOrder = 0;
    final int maxorders=10;
     private Order [] orderArray = new Order[maxorders];
            // TODO -- declare maximum orders constant
            // TODO -- declare Order object array
            // TODO -- declare current order variable


            private JLabel titleLabel1 = new JLabel("Technician Details"); // program title            
            private JLabel titleLabel2= new JLabel("Building Details"); // program title
            private JLabel titleLabe3 = new JLabel("Installation Details"); // program title

            private JLabel nameT = new JLabel("Name: ");// for prompt
            private JTextField nameTField = new JTextField(26);      // for name entry

            private JLabel phoneT = new JLabel("Phone No: ");// for prompt
            private JTextField phoneTField = new JTextField(26);
            
            private JLabel addressB = new JLabel("Address: ");// for prompt
            private JTextField addressBField = new JTextField(26);
            
            
            private JLabel hpB = new JLabel("HP: ");// for prompt
            private JTextField hpBField = new JTextField(26);
            
            
            private JLabel zoneB = new JLabel("Zone: ");// for prompt
            private JTextField zoneBField = new JTextField(26);
            
            
            private JLabel outletB = new JLabel("Outlet: ");// for prompt
            private JTextField outletBField = new JTextField(26);
            
            
            private JLabel startDI = new JLabel("Start Date: ");// for prompt
            private JTextField startDIField = new JTextField(26);
            
            
            private JLabel endDI = new JLabel("End Date: ");// for prompt
            private JTextField endDIField = new JTextField(26);
            
            

//            private JTextArea displayTextArea = new JTextArea("", 16, 56); // declare text area
//            private JScrollPane scrollPane; // scroll pane for the text area

            //  declare all of the buttons
            private JButton enterButton = new JButton("Add"); // buttons
            private JButton displayButton = new JButton("Clear");
            private JButton searchButton = new JButton("Exit");
            private JButton exitButton = new JButton("Display");



            // Main method create instance of class
            public static void main(String[] args)
            {
                    RockyDryCleanersGUI f = new RockyDryCleanersGUI();			// Create instance of class
                    f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	// allow the code to close the program
                    f.setBounds(200, 100, 470, 440);						// Define position and size of app
                    f.setTitle("Rocky Dry Cleaners Management System");		// Set the title of the app
                    f.setVisible(true);										// Make the application visible
                    f.setResizable(false);									// Make the window not resizable
            } // main


            public acGui()
            { // constructor create the Gui
                    this.setLayout(new FlowLayout());			// set JFrame to FlowLayout

                    titleLabel1.setFont(new Font("Ariel", Font.BOLD, 22));
                    add(titleLabel1);
                    add(nameT);
                    add(nameTField);
                    add(phoneT);
                    add(phoneTField);

                    // set text area to a monospaced font so the columns can be aligned using a format string
//                    displayTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
//                    displayTextArea.setEditable(false); 			// make text area read only
//                    scrollPane = new JScrollPane(displayTextArea); 	// add text area to the scroll pane
//                    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // just need vertical scrolling

//                    add(scrollPane);

                    add(enterButton);
                    add(displayButton);
                    add(searchButton);
                    add(exitButton);

//                    enterButton.addActionListener(this);		// add the action listener to the buttons
//                    displayButton.addActionListener(this);
//                    searchButton.addActionListener(this);
//                    exitButton.addActionListener(this);



                    // when the user pushes the system close (X top right corner)
                    addWindowListener( // override window closing method
                            new WindowAdapter()
                            {
                                    public void windowClosing(WindowEvent e)
                                    {
//                                            exit();				// Attempt to exit application
                                    }
                            }
                    );
            }



//            public void actionPerformed(ActionEvent e)
//            { // process the clicks on all of the buttons
//                    String command = e.getActionCommand();
//
//                    if (command.compareTo("Enter") == 0)
//                            enter();
//                    else if (command.compareTo("Display All") == 0)
//                            displayAll();
//                    else if (command.compareTo("Search") == 0)
//                            search();
//                    else if (command.compareTo("Exit") == 0)
//                            exit();
//            }
//   
//            private void enter()
//            {
//                    // TODO -- complete error message code (put this code at the beginning of the method)
//                if(currentOrder>=maxorders){
//                            JOptionPane.showMessageDialog(rootPane, "Maximum number of orders has been reached", "Rocky Dry Cleaners Management System", HEIGHT);
//                        }else if(nameField.getText().compareTo("") == 0) {
//                        JOptionPane.showMessageDialog(rootPane, "Please Enter customer name", "Rocky Dry Cleaners Management System", HEIGHT);
//                        nameField.requestFocus();
//                    }else if(garmentsField.getText().compareTo("") == 0) {
//                        JOptionPane.showMessageDialog(rootPane, "Please Enter Number of Garments", "Rocky Dry Cleaners Management System", HEIGHT);
//                        garmentsField.requestFocus();
//                    }else{
//                        String customerName = nameField.getText();
//                        int garments = Integer.parseInt(garmentsField.getText());
//                        orderArray[currentOrder] =new Order(customerName, garments);
//                        displayHeading();
//                        displayTextArea.append(String.format("%-30s%-17s%-6s\n", orderArray[currentOrder].getCustomerName(), orderArray[currentOrder].getGarments(), orderArray[currentOrder].calculateCharge()));
//                       
//                    
//                    // TODO -- Clear input fields and return focus to the customer name field and increment current booking variable
//                        nameField.setText("");
//                        garmentsField.setText("");
//                        nameField.requestFocus();
//                        currentOrder=currentOrder+1;
//                    }
//            }
//
//
//            private void displayHeading()
//            {
//                    displayTextArea.setText(String.format("%-30s%-17s%-6s\n", "Customer Name", "Garments", "Charge"));
//                    appendLine();
//            }
//
//
//            private void appendLine()
//            {
//                    displayTextArea.append("-------------------------------------------------------\n");
//            }
//            private void data(int i){
//                     }
//            private void displayAll()
//            {
//                    // TODO -- display all of the entries entered so far
//                    displayHeading();
//                    int gA=0;
//                    double cT=0;
//                    for(int i =0;i<currentOrder;i++){
//                        displayTextArea.append(String.format("%-30s%-17s%-6s\n", orderArray[i].getCustomerName(), orderArray[i].getGarments(), orderArray[i].calculateCharge()));
//                        gA=gA+orderArray[i].getGarments();
//                        cT=cT+orderArray[i].calculateCharge();
//                    }
//                    // TODO -- display average garments per order and total charges collected
//                    appendLine();
//                    displayTextArea.append(String.format("Average garments per order: %.2f\n",(double) gA/(currentOrder)));
//                    displayTextArea.append(String.format("Total charges: $%s",cT));
//                    // TODO -- complete error message code
//                    if (currentOrder == 0) {
//                    JOptionPane.showMessageDialog(rootPane, "No order entered", "Rocky Dry Cleaners Management System", HEIGHT);
//                    }
//            }
//
//
//            private void search()
//            {
//                if (currentOrder == 0) {
//                    JOptionPane.showMessageDialog(rootPane, "No order entered", "Rocky Dry Cleaners Management System", HEIGHT);
//                    }
//                // TODO -- read search key (customer name) from input dialog
//                    String search = JOptionPane.showInputDialog(rootPane, "Enter a customer name to search", "Search", HEIGHT);
//                // TODO -- complete error message code
//                    if (search.equals("")) {
//                    JOptionPane.showMessageDialog(rootPane, "You must enter a search name", "Rocky Dry Cleaners Management System", HEIGHT);
//                    }else{
//                // TODO -- iterate through array to search for the search key
//                    int a=0;
//                    displayHeading();
//                    for(int i=0;i<currentOrder;i++){
//                        if(search.equalsIgnoreCase(orderArray[i].getCustomerName())) {
//                            displayTextArea.append(String.format("%-30s%-17s%-6s\n", orderArray[i].getCustomerName(), orderArray[i].getGarments(), orderArray[i].calculateCharge()));
//                            a=1;
//                        }
//                    }
//                    if(a==0){
//                        JOptionPane.showMessageDialog(rootPane,String.format("%s not found", search) , "Rocky Dry Cleaners Management System", HEIGHT);
//                    }
//                // TODO -- display the entry if it exists or an error message if it doesn't
//                }
//            }
//
//            private void exit()
//            {
//                    // TODO -- display exit message h
//                    
//                    JOptionPane.showMessageDialog(rootPane,"Thank You for using Rocky Dry Cleaners Management System" , "Rocky Dry Cleaners Management System", HEIGHT);
//                    System.exit(0);
//                    
//            } // exit
//
//
//
//        
//
//    
//
//    }
//
//
//
}
