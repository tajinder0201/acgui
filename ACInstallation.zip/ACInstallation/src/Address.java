/*
 File Name-ACInstallation.java
Student Name-Tajinder Pal Singh
Student ID-12095732
 */


public class Address extends Dates{
    String address;
    String hp;
    String zone;
    String outlet;
    
    //parameterized constructor
    public Address(String address, String hp, String zone, String outlet, String start, String end) {
        super(start, end);
        this.address = address;
        this.hp = hp;
        this.zone = zone;
        this.outlet = outlet;
    }

     //get method for address variable
    public String getAddress() {
        return address;
    }

     //set method for address variable
    public void setAddress(String address) {
        this.address = address;
    }

     //get method for zone variable
    public String getZone() {
        return zone;
    }

     //get method for outlet variable
    public String getOutlet() {
        return outlet;
    }

     //get method for hp variable
    public String getHp() {
        return hp;
    }

     //set method for zone variable
    public void setZone(String zone) {
        this.zone = zone;
    }

     //set method for Outlet variable
    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

     //set method for hp variable
    public void setHp(String hp) {
        this.hp = hp;
    }
    
    @Override
    public String toString() {
        return "\nAddress Details\nAddress = "+getAddress()+"\nHp = "+getHp()+"\tZone = "+getZone()+"\tOutlet = "+getOutlet()+super.toString();
    }
}