/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DEll
 */
public class Details extends Address{
    String name;
    String phone;
    public Details(String name, String phone, String address, String hp, String zone, String outlet, String start, String end) {
        super(address, hp, zone, outlet, start, end);
        this.name = name;
        this.phone = phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }
    
    @Override
    public String toString() {
        return "Technicain Details|"+getName()+"|\nName = "+getName()+"\tPhone No = "+getPhone()+super.toString()+"\n-------------------------------------------------------\n";
    }
}