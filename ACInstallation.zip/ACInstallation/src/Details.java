/*
 *File Name-Details.java
Student Name-Tajinder Pal Singh
Student ID-12095732
 */
public class Details extends Address{
    String name; //String type for name variable
    String phone; //String type for phone variable
    
    //parameterized constructor
    public Details(String name, String phone, String address, String hp, String zone, String outlet, String start, String end) {
        super(address, hp, zone, outlet, start, end); //using inheritence
        this.name = name;
        this.phone = phone;
    }

    //set method for phone variable
    public void setPhone(String phone) {
        this.phone = phone;
    }

     //set method for name variable
    public void setName(String name) {
        this.name = name;
    }

     //get method for phone variable
    public String getPhone() {
        return phone;
    }

     //get method for name variable
    public String getName() {
        return name;
    }
    
    @Override
    public String toString() {
        return "Technicain Details\nName = "+getName()+"\tPhone No = "+getPhone()+super.toString()+"\n-------------------------------------------------------\n";
    }
}