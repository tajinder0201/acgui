/*
 File Name-ACInstallation.java
Student Name-Tajinder Pal Singh
Student ID-12095732
 */
class Dates {
    String start; //String type for Start variable
    String end; //String type for end variable
    
    //parameterized constructor
    public Dates(String start, String end) {
        this.start = start;
        this.end = end;
    }

     //set method for end variable
    public void setEnd(String end) {
        this.end = end;
    }

     //get method for end variable
    public String getEnd() {
        return end;
    }

     //set method for start variable
    public void setStart(String start) {
        this.start = start;
    }

     //get method for start variable
    public String getStart() {
        return start;
    }

    @Override
    public String toString() {
        return "\nInstallation Dates\nStart Date = " + getStart()+ "\tEnd Date = "+ getEnd();
    }
}
