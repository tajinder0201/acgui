/*
 File Name-ACInstallation.java
Student Name-Tajinder Pal Singh
Student ID-12095732
 */
public class components {
    String hp, zone, outlet; //String type for hp, zone and outlet
    
    //parameterized constructor
    public components(String hp, String zone, String outlet){
        this.hp = hp;
        this.zone = zone;
        this.outlet = outlet;
    }
    
     //set method for zone variable
    public void setZone(String zone) {
        this.zone = zone;
    }

     //set method for outlet variable
    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

     //set method for hp variable
    public void setHp(String hp) {
        this.hp = hp;
    }

     //get method for zone variable
    public String getZone() {
        return zone;
    }

     //get method for outlet variable
    public String getOutlet() {
        return outlet;
    }

     //get method for hp variable
    public String getHp() {
        return hp;
    }
}
