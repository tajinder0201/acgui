/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DEll
 */
public class Address extends Dates{
    String address;
    String hp;
    String zone;
    String outlet;
    public Address(String address, String hp, String zone, String outlet, String start, String end) {
        super(start, end);
        this.address = address;
        this.hp = hp;
        this.zone = zone;
        this.outlet = outlet;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZone() {
        return zone;
    }

    public String getOutlet() {
        return outlet;
    }

    public String getHp() {
        return hp;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public void setOutlet(String outlet) {
        this.outlet = outlet;
    }

    public void setHp(String hp) {
        this.hp = hp;
    }
    @Override
    public String toString() {
        return "\nAddress Details\nAddress = "+getAddress()+"\nHp = "+getHp()+"\tZone = "+getZone()+"\tOutlet = "+getOutlet()+super.toString();
    }
}